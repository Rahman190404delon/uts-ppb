package com.example.projectnew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
